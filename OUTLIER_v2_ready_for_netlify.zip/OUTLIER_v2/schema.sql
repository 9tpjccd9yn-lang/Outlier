-- OUTLIER 2.0 — run once in Supabase SQL Editor.
create table if not exists public.results (
 id bigint generated always as identity primary key,
 user_id uuid not null references auth.users(id) on delete cascade,
 mode text not null check(mode in ('daily','infinite','duel')),
 won boolean not null,
 created_at timestamptz not null default now()
);
create table if not exists public.lobbies (
 code text primary key check (code ~ '^[A-Z2-9]{6}$'),
 host_id uuid not null references auth.users(id) on delete cascade,
 guest_id uuid references auth.users(id) on delete set null,
 question_index integer not null check(question_index between 0 and 36),
 turn text not null default 'host' check(turn in ('host','guest')),
 guesses jsonb not null default '[]'::jsonb,
 status text not null default 'waiting' check(status in ('waiting','playing','done')),
 winner_id uuid references auth.users(id),
 created_at timestamptz not null default now()
);
alter table public.results enable row level security;
alter table public.lobbies enable row level security;
revoke all on public.results, public.lobbies from anon;
grant select, insert on public.results to authenticated;
grant select, insert on public.lobbies to authenticated;
grant usage, select on sequence public.results_id_seq to authenticated;
drop policy if exists results_read on public.results;
create policy results_read on public.results for select to authenticated using(user_id=auth.uid());
drop policy if exists results_insert on public.results;
create policy results_insert on public.results for insert to authenticated with check(user_id=auth.uid() and mode in ('daily','infinite'));
drop policy if exists lobby_read on public.lobbies;
create policy lobby_read on public.lobbies for select to authenticated using(host_id=auth.uid() or guest_id=auth.uid());
drop policy if exists lobby_create on public.lobbies;
create policy lobby_create on public.lobbies for insert to authenticated with check(host_id=auth.uid() and guest_id is null and status='waiting' and turn='host' and guesses='[]'::jsonb and winner_id is null);
-- Clients cannot update lobby rows directly; all turns go through locked server-side functions.
create or replace function public.join_outlier_lobby(p_code text)
returns public.lobbies language plpgsql security definer set search_path=public as $$
declare v public.lobbies;
begin
 if auth.uid() is null then raise exception 'Sign in first'; end if;
 select * into v from public.lobbies where code=upper(trim(p_code)) for update;
 if not found then raise exception 'Lobby not found'; end if;
 if v.host_id=auth.uid() or v.guest_id=auth.uid() then return v; end if;
 if v.guest_id is not null then raise exception 'Lobby is full'; end if;
 update public.lobbies set guest_id=auth.uid(),status='playing' where code=v.code returning * into v;
 return v;
end $$;
create or replace function public.play_outlier_turn(p_code text,p_guess bigint)
returns public.lobbies language plpgsql security definer set search_path=public as $$
declare v public.lobbies; a bigint; player text; updated_guesses jsonb; n integer;
begin
 if auth.uid() is null then raise exception 'Sign in first'; end if;
 if p_guess<0 or p_guess>9000000000000 then raise exception 'Invalid guess'; end if;
 select * into v from public.lobbies where code=upper(trim(p_code)) for update;
 if not found then raise exception 'Lobby not found'; end if;
 if v.status<>'playing' or v.guest_id is null then raise exception 'Lobby is not ready'; end if;
 player:=case when auth.uid()=v.host_id then 'host' when auth.uid()=v.guest_id then 'guest' else null end;
 if player is null then raise exception 'You are not in this lobby'; end if;
 if player<>v.turn then raise exception 'Wait for your turn'; end if;
 n:=jsonb_array_length(v.guesses);
 if n>=10 then raise exception 'Round is over'; end if;
 a:=(array[38,10935,97,35,21196,632,8,828,706,320,30,7300,8,3475,73,958,14,27,50,665,116,979,12,80,502,40075,11,66,1082,50,22,79,93,6650,10,90,10])[v.question_index+1];
 updated_guesses:=v.guesses||jsonb_build_array(jsonb_build_object('by',player,'value',p_guess));
 update public.lobbies set guesses=updated_guesses,turn=case when player='host' then 'guest' else 'host' end,
 status=case when p_guess=a or n+1>=10 then 'done' else 'playing' end,
 winner_id=case when p_guess=a then auth.uid() else null end where code=v.code returning * into v;
 if p_guess=a then insert into public.results(user_id,mode,won) values(auth.uid(),'duel',true); end if;
 return v;
end $$;
create or replace function public.reset_outlier_lobby(p_code text,p_question_index integer)
returns public.lobbies language plpgsql security definer set search_path=public as $$
declare v public.lobbies;
begin
 if auth.uid() is null then raise exception 'Sign in first'; end if;
 if p_question_index<0 or p_question_index>36 then raise exception 'Invalid question'; end if;
 select * into v from public.lobbies where code=upper(trim(p_code)) for update;
 if not found or v.host_id<>auth.uid() then raise exception 'Only host can reset'; end if;
 if v.status<>'done' then raise exception 'Finish the round first'; end if;
 update public.lobbies set question_index=p_question_index,guesses='[]'::jsonb,turn='guest',status=case when guest_id is null then 'waiting' else 'playing' end,winner_id=null where code=v.code returning * into v;
 return v;
end $$;
revoke all on function public.join_outlier_lobby(text) from public,anon;
revoke all on function public.play_outlier_turn(text,bigint) from public,anon;
revoke all on function public.reset_outlier_lobby(text,integer) from public,anon;
grant execute on function public.join_outlier_lobby(text) to authenticated;
grant execute on function public.play_outlier_turn(text,bigint) to authenticated;
grant execute on function public.reset_outlier_lobby(text,integer) to authenticated;
