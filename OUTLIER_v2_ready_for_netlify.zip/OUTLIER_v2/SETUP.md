# OUTLIER 2.0 — Deploy and enable online features

## Publish the updated website (works immediately)
1. Extract this ZIP. Open the OUTLIER_v2 folder and check it contains `index.html` and the Google verification file.
2. Upload the **OUTLIER_v2 folder** to **your existing OUTLIER Netlify project → Deploys**. Do not create a new site.
3. Check https://outlier-game.netlify.app/ . Daily, Infinite and browser-local stats work immediately.
4. The Google verification meta tag and verification file are retained.

## Enable real accounts and online friend lobbies (one-time setup)
These features are intentionally **disabled until connected**. A static HTML file cannot provide secure accounts or real-time online multiplayer on its own.

1. Create a Supabase project at https://supabase.com . Use a strong database password.
2. In **SQL Editor**, paste and run the entire `schema.sql` file. It creates protected tables and server-side turn logic.
3. In **Authentication → Providers**, enable Email. In **Authentication → URL Configuration**, set Site URL to `https://outlier-game.netlify.app` and add `https://outlier-game.netlify.app/**` as an allowed redirect URL. For easiest sign-in, use email magic links; email delivery limits may apply.
4. In **Project Settings → API** (or **Connect**), copy the **Project URL** and **publishable/anon public key**. Never use or publish the **service_role/secret** key.
5. Open `index.html` in Notepad. Near the start of the JavaScript find:
   `const CONFIG={url:'',anonKey:''};`
   Replace the two empty strings with your project URL and public anon/publishable key, keeping quotes.
6. Save the file as `index.html` (not `index.html.txt`), upload the folder to your existing Netlify project again.
7. Test with two different accounts/devices. In **Profile**, enter an email and use the sign-in link. In **Duel**, create a lobby, share the link, have a second signed-in player join, and take turns.

## Important limits and notes
- Game stats before sign-in remain in browser local storage and are not automatically imported. New daily/infinite results are also written to the database after sign-in; the Profile display currently shows local device stats, not a merged online history.
- Duel victories are stored online, but the local 'Duel wins' tile is not yet synchronized. This is a starter release, not a fully complete cross-device stats dashboard.
- Online lobby state refreshes every two seconds. Lobbies are two-player, ten guesses combined, and turn-based. The host can start a new round.
- Answers live in the browser code, so technically savvy players can inspect them. Competitive anti-cheat requires moving questions/answers to the server.
- Questions are curated and do not automatically pull fresh news. Update the NEWS array with verified current events periodically.
- The game and verification are public; Google indexing is separate and not guaranteed.
